/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ArchiveProviderConfig {
    /**
    * Alias name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/archive/2.8.0/docs#alias ArchiveProvider#alias}
    */
    readonly alias?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/archive/2.8.0/docs archive}
*/
export declare class ArchiveProvider extends cdktn.TerraformProvider {
    static readonly tfResourceType = "archive";
    /**
    * Generates CDKTN code for importing a ArchiveProvider resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ArchiveProvider to import
    * @param importFromId The id of the existing ArchiveProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/archive/2.8.0/docs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ArchiveProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/archive/2.8.0/docs archive} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ArchiveProviderConfig = {}
    */
    constructor(scope: Construct, id: string, config?: ArchiveProviderConfig);
    private _alias?;
    get alias(): string | undefined;
    set alias(value: string | undefined);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
