/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface FileConfig extends cdktn.TerraformMetaArguments {
    /**
    * Boolean flag indicating whether symbolically linked directories should be excluded during the creation of the archive. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/archive/2.8.1/docs/resources/file#exclude_symlink_directories File#exclude_symlink_directories}
    */
    readonly excludeSymlinkDirectories?: boolean | cdktn.IResolvable;
    /**
    * Specify files/directories to ignore when reading the `source_dir`. Supports glob file matching patterns including doublestar/globstar (`**`) patterns.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/archive/2.8.1/docs/resources/file#excludes File#excludes}
    */
    readonly excludes?: string[];
    /**
    * String that specifies the octal file mode for all archived files. For example: `"0666"`. Setting this will ensure that cross platform usage of this module will not vary the modes of archived files (and ultimately checksums) resulting in more deterministic behavior.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/archive/2.8.1/docs/resources/file#output_file_mode File#output_file_mode}
    */
    readonly outputFileMode?: string;
    /**
    * The output of the archive file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/archive/2.8.1/docs/resources/file#output_path File#output_path}
    */
    readonly outputPath: string;
    /**
    * Add only this content to the archive with `source_content_filename` as the filename. One and only one of `source`, `source_content_filename` (with `source_content`), `source_file`, or `source_dir` must be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/archive/2.8.1/docs/resources/file#source_content File#source_content}
    */
    readonly sourceContent?: string;
    /**
    * Set this as the filename when using `source_content`. One and only one of `source`, `source_content_filename` (with `source_content`), `source_file`, or `source_dir` must be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/archive/2.8.1/docs/resources/file#source_content_filename File#source_content_filename}
    */
    readonly sourceContentFilename?: string;
    /**
    * Package entire contents of this directory into the archive. One and only one of `source`, `source_content_filename` (with `source_content`), `source_file`, or `source_dir` must be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/archive/2.8.1/docs/resources/file#source_dir File#source_dir}
    */
    readonly sourceDir?: string;
    /**
    * Package this file into the archive. One and only one of `source`, `source_content_filename` (with `source_content`), `source_file`, or `source_dir` must be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/archive/2.8.1/docs/resources/file#source_file File#source_file}
    */
    readonly sourceFile?: string;
    /**
    * The type of archive to generate. NOTE: `zip` and `tar.gz` is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/archive/2.8.1/docs/resources/file#type File#type}
    */
    readonly type: string;
    /**
    * source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/archive/2.8.1/docs/resources/file#source File#source}
    */
    readonly source?: FileSource[] | cdktn.IResolvable;
}
export interface FileSource {
    /**
    * Add this content to the archive with `filename` as the filename.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/archive/2.8.1/docs/resources/file#content File#content}
    */
    readonly content: string;
    /**
    * Set this as the filename when declaring a `source`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/archive/2.8.1/docs/resources/file#filename File#filename}
    */
    readonly filename: string;
}
export declare function fileSourceToTerraform(struct?: FileSource | cdktn.IResolvable): any;
export declare function fileSourceToHclTerraform(struct?: FileSource | cdktn.IResolvable): any;
export declare class FileSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): FileSource | cdktn.IResolvable | undefined;
    set internalValue(value: FileSource | cdktn.IResolvable | undefined);
    private _content?;
    get content(): string;
    set content(value: string);
    get contentInput(): string | undefined;
    private _filename?;
    get filename(): string;
    set filename(value: string);
    get filenameInput(): string | undefined;
}
export declare class FileSourceList extends cdktn.ComplexList {
    internalValue?: FileSource[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): FileSourceOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/archive/2.8.1/docs/resources/file archive_file}
*/
export declare class File extends cdktn.TerraformResource {
    static readonly tfResourceType = "archive_file";
    /**
    * Generates CDKTN code for importing a File resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the File to import
    * @param importFromId The id of the existing File that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/archive/2.8.1/docs/resources/file#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the File to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/archive/2.8.1/docs/resources/file archive_file} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options FileConfig
    */
    constructor(scope: Construct, id: string, config: FileConfig);
    private _excludeSymlinkDirectories?;
    get excludeSymlinkDirectories(): boolean | cdktn.IResolvable;
    set excludeSymlinkDirectories(value: boolean | cdktn.IResolvable);
    resetExcludeSymlinkDirectories(): void;
    get excludeSymlinkDirectoriesInput(): boolean | cdktn.IResolvable | undefined;
    private _excludes?;
    get excludes(): string[];
    set excludes(value: string[]);
    resetExcludes(): void;
    get excludesInput(): string[] | undefined;
    get id(): string;
    get outputBase64Sha256(): string;
    get outputBase64Sha512(): string;
    private _outputFileMode?;
    get outputFileMode(): string;
    set outputFileMode(value: string);
    resetOutputFileMode(): void;
    get outputFileModeInput(): string | undefined;
    get outputMd5(): string;
    private _outputPath?;
    get outputPath(): string;
    set outputPath(value: string);
    get outputPathInput(): string | undefined;
    get outputSha(): string;
    get outputSha256(): string;
    get outputSha512(): string;
    get outputSize(): number;
    private _sourceContent?;
    get sourceContent(): string;
    set sourceContent(value: string);
    resetSourceContent(): void;
    get sourceContentInput(): string | undefined;
    private _sourceContentFilename?;
    get sourceContentFilename(): string;
    set sourceContentFilename(value: string);
    resetSourceContentFilename(): void;
    get sourceContentFilenameInput(): string | undefined;
    private _sourceDir?;
    get sourceDir(): string;
    set sourceDir(value: string);
    resetSourceDir(): void;
    get sourceDirInput(): string | undefined;
    private _sourceFile?;
    get sourceFile(): string;
    set sourceFile(value: string);
    resetSourceFile(): void;
    get sourceFileInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _source;
    get source(): FileSourceList;
    putSource(value: FileSource[] | cdktn.IResolvable): void;
    resetSource(): void;
    get sourceInput(): cdktn.IResolvable | FileSource[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
